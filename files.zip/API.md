# API CONTRACTS — RDAM
## Poder Judicial de Santa Fe

**Base URL:** `https://api.rdam.justiciasantafe.gov.ar/api`  
**Auth:** Bearer JWT (endpoints internos) | Público (endpoints ciudadano)  
**Content-Type:** `application/json` (salvo upload multipart)

---

## AUTENTICACIÓN

### POST /auth/login
Login de usuario interno.

**Request:**
```json
{
  "username": "operario.rodriguez",
  "password": "contraseña123"
}
```

**Response 200:**
```json
{
  "access_token": "eyJhbGci...",
  "refresh_token": "eyJhbGci...",
  "expires_in": 28800,
  "usuario": {
    "id": "uuid",
    "username": "operario.rodriguez",
    "nombre_completo": "Lucía Rodríguez",
    "rol": "OPERARIO",
    "circunscripcion": "SANTA_FE"
  }
}
```

**Response 401:**
```json
{ "error": "CREDENCIALES_INVALIDAS", "message": "Usuario o contraseña incorrectos" }
```

---

### POST /auth/refresh
Renovar access token.

**Request:**
```json
{ "refresh_token": "eyJhbGci..." }
```

**Response 200:**
```json
{ "access_token": "eyJhbGci...", "expires_in": 28800 }
```

---

## SOLICITUDES — ENDPOINTS PÚBLICOS (Portal Ciudadano)

### POST /solicitudes
Crear nueva solicitud (ciudadano).

**Request:**
```json
{
  "dni": "30456789",
  "cuil": "20304567894",
  "nombre_completo": "García Martínez, Juan Carlos",
  "fecha_nacimiento": "1985-03-15",
  "email": "jgarcia@email.com",
  "circunscripcion": "SANTA_FE"
}
```

**Response 201:**
```json
{
  "id": "uuid",
  "codigo": "RDAM-2025-00247",
  "estado": "PENDIENTE_REVISION",
  "fecha_creacion": "2025-01-14T10:32:00Z",
  "mensaje": "Tu solicitud fue recibida correctamente. El personal del Poder Judicial la revisará en breve."
}
```

**Response 422 (validación):**
```json
{
  "error": "VALIDACION",
  "campos": {
    "dni": "Formato inválido. Ingresá solo números.",
    "email": "Email inválido."
  }
}
```

---

### GET /solicitudes/consulta
Consultar estado por código o DNI+email (ciudadano).

**Query params:**
- `codigo=RDAM-2025-00247` ó
- `dni=30456789&email=jgarcia@email.com`

**Response 200:**
```json
{
  "codigo": "RDAM-2025-00247",
  "nombre_completo": "García Martínez, Juan Carlos",
  "circunscripcion": "SANTA_FE",
  "estado": "PAGADA",
  "observaciones_rechazo": null,
  "fecha_creacion": "2025-01-14T10:32:00Z",
  "fecha_actualizacion": "2025-01-15T09:20:00Z",
  "timeline": [
    { "estado": "PENDIENTE_REVISION", "fecha": "2025-01-14T10:32:00Z", "descripcion": "Solicitud creada" },
    { "estado": "EN_REVISION", "fecha": "2025-01-14T11:15:00Z", "descripcion": "En revisión" },
    { "estado": "APROBADA", "fecha": "2025-01-14T11:48:00Z", "descripcion": "Aprobada" },
    { "estado": "PENDIENTE_PAGO", "fecha": "2025-01-14T11:48:00Z", "descripcion": "Habilitada para pago" },
    { "estado": "PAGADA", "fecha": "2025-01-15T09:20:00Z", "descripcion": "Pago confirmado" }
  ]
}
```

---

### GET /solicitudes/historial
Historial de solicitudes del ciudadano por DNI.

**Query params:** `dni=30456789`

**Response 200:**
```json
{
  "solicitudes": [
    {
      "codigo": "RDAM-2025-00247",
      "estado": "PAGADA",
      "circunscripcion": "SANTA_FE",
      "fecha_creacion": "2025-01-14T10:32:00Z",
      "pdf_disponible": false,
      "fecha_vencimiento": null
    },
    {
      "codigo": "RDAM-2024-01823",
      "estado": "EMITIDA",
      "circunscripcion": "SANTA_FE",
      "fecha_creacion": "2024-09-03T08:00:00Z",
      "pdf_disponible": true,
      "fecha_vencimiento": "2024-12-01T14:30:00Z",
      "pdf_url": "https://..."
    }
  ]
}
```

---

### GET /solicitudes/:codigo/download
Descargar certificado PDF (requiere que esté emitido y vigente).

**Query params:** `dni=30456789`

**Response 200:** Redirect a URL presignada S3 (302) o stream del PDF.

**Response 403:**
```json
{ "error": "NO_AUTORIZADO", "message": "DNI no corresponde a esta solicitud" }
```

**Response 410:**
```json
{ "error": "CERTIFICADO_VENCIDO", "message": "El certificado venció el 01/12/2024" }
```

---

## PAGO

### POST /pagos/iniciar
Iniciar proceso de pago (luego de que la solicitud está APROBADA).

**Request:**
```json
{
  "codigo_solicitud": "RDAM-2025-00247",
  "email": "jgarcia@email.com"
}
```

**Response 200:**
```json
{
  "transaccion_id": "uuid",
  "url_pago": "https://pasarela.externa.com/checkout/PAY-ABC-12345",
  "monto": 2750.00,
  "expira_en": 3600
}
```

---

### POST /webhooks/pago
Webhook entrante de la pasarela de pago (firmado con secret compartido).

**Headers:**
```
X-Pasarela-Signature: sha256=...
```

**Request:**
```json
{
  "evento": "PAGO_CONFIRMADO",
  "referencia_interna": "RDAM-2025-00247",
  "referencia_pasarela": "PAY-ABC-12345",
  "monto": 2750.00,
  "metodo": "TARJETA_CREDITO",
  "timestamp": "2025-01-15T09:20:00Z"
}
```

**Response 200:**
```json
{ "procesado": true }
```

---

## SOLICITUDES — ENDPOINTS INTERNOS (Backoffice — JWT requerido)

### GET /admin/solicitudes
Listar solicitudes con filtros avanzados.

**Auth:** Bearer JWT (OPERARIO ve solo su circunscripción, SUPERVISOR ve todas)

**Query params:**
- `estado=PENDIENTE_REVISION`
- `circunscripcion=SANTA_FE`
- `from=2025-01-01` / `to=2025-01-31`
- `dni_hash=abc123` (búsqueda por DNI, se hashea en cliente)
- `operario_id=uuid` (solo SUPERVISOR)
- `page=1` / `limit=20`
- `sort=fecha_creacion` / `order=asc`

**Response 200:**
```json
{
  "data": [
    {
      "id": "uuid",
      "codigo": "RDAM-2025-00231",
      "nombre_completo": "López Pérez, María",
      "email": "mlopez@email.com",
      "circunscripcion": "ROSARIO",
      "estado": "PENDIENTE_REVISION",
      "operario_asignado": null,
      "fecha_creacion": "2025-01-10T09:00:00Z",
      "horas_en_estado": 124,
      "alerta_sla": true
    }
  ],
  "total": 248,
  "page": 1,
  "limit": 20,
  "pages": 13
}
```

---

### GET /admin/solicitudes/:id
Obtener detalle completo de una solicitud.

**Auth:** OPERARIO (solo asignadas a él o de su circunscripción) | SUPERVISOR (todas)

**Response 200:**
```json
{
  "id": "uuid",
  "codigo": "RDAM-2025-00235",
  "dni_enmascarado": "••••••789",
  "cuil_enmascarado": "20-••••••89-4",
  "nombre_completo": "Fernández, Roberto A.",
  "fecha_nacimiento": "1978-06-22",
  "email": "rfernandez@gmail.com",
  "circunscripcion": "SANTA_FE",
  "estado": "EN_REVISION",
  "operario_asignado": { "id": "uuid", "nombre": "L. Rodríguez" },
  "observaciones_rechazo": null,
  "validaciones": {
    "identidad": { "resultado": "OK", "descripcion": "Sin irregularidades" },
    "registro_rdam": { "resultado": "OK", "descripcion": "No figura" },
    "consistencia_datos": { "resultado": "OK", "descripcion": "CUIL consistente" },
    "solicitudes_previas": { "resultado": "WARN", "descripcion": "1 solicitud previa encontrada" }
  },
  "pdf_url": null,
  "fecha_emision": null,
  "fecha_vencimiento": null,
  "fecha_creacion": "2025-01-11T10:32:00Z",
  "fecha_actualizacion": "2025-01-11T11:15:00Z",
  "auditoria": [
    {
      "accion": "SOLICITUD_CREADA",
      "usuario": null,
      "estado_anterior": null,
      "estado_nuevo": "PENDIENTE_REVISION",
      "timestamp": "2025-01-11T10:32:00Z"
    },
    {
      "accion": "TOMADA_PARA_REVISION",
      "usuario": { "id": "uuid", "nombre": "L. Rodríguez" },
      "estado_anterior": "PENDIENTE_REVISION",
      "estado_nuevo": "EN_REVISION",
      "timestamp": "2025-01-11T11:15:00Z"
    }
  ]
}
```

---

### PATCH /admin/solicitudes/:id/estado
Cambiar estado de una solicitud.

**Auth:** Según transición permitida por rol.

**Request:**
```json
{
  "estado": "APROBADA",
  "observaciones": "Documentación verificada correctamente"
}
```

```json
// Para rechazo
{
  "estado": "RECHAZADA",
  "observaciones": "Los datos de CUIL no coinciden con el DNI provisto"
}
```

```json
// Forzar estado (solo SUPERVISOR)
{
  "estado": "EN_REVISION",
  "observaciones": "Reapertura autorizada por el supervisor",
  "forzado": true
}
```

**Response 200:**
```json
{
  "id": "uuid",
  "codigo": "RDAM-2025-00235",
  "estado": "APROBADA",
  "fecha_actualizacion": "2025-01-11T11:48:00Z"
}
```

**Response 422:**
```json
{
  "error": "TRANSICION_INVALIDA",
  "message": "No se puede transicionar de EMITIDA a PENDIENTE_REVISION sin permisos de supervisor"
}
```

---

### POST /admin/solicitudes/:id/pdf
Cargar certificado PDF (emisión).

**Auth:** OPERARIO (solo solicitudes PAGADAS de su circunscripción) | SUPERVISOR (todas PAGADAS)

**Content-Type:** `multipart/form-data`

**Form fields:**
- `pdf`: archivo PDF (máx 5MB)

**Response 200:**
```json
{
  "id": "uuid",
  "codigo": "RDAM-2025-00241",
  "estado": "EMITIDA",
  "pdf_url": "https://storage.rdam.../RDAM-2025-00241.pdf?token=...",
  "fecha_emision": "2025-01-15T14:30:00Z",
  "fecha_vencimiento": "2025-04-15T14:30:00Z",
  "email_enviado": true
}
```

**Response 400:**
```json
{ "error": "ARCHIVO_INVALIDO", "message": "Solo se aceptan archivos PDF de hasta 5MB" }
```

---

### PATCH /admin/solicitudes/:id/asignar
Asignar/reasignar operario a una solicitud.

**Auth:** Solo SUPERVISOR

**Request:**
```json
{ "operario_id": "uuid" }
```

**Response 200:**
```json
{
  "codigo": "RDAM-2025-00231",
  "operario_asignado": { "id": "uuid", "nombre": "M. González" }
}
```

---

## DASHBOARD (Solo SUPERVISOR)

### GET /admin/dashboard
Métricas del panel de control.

**Query params:** `periodo=30d` (7d, 30d, custom con from/to)

**Response 200:**
```json
{
  "kpis": {
    "total": 248,
    "pendientes_revision": 23,
    "en_revision": 12,
    "emitidas_hoy": 8,
    "rechazadas_total": 14,
    "tasa_rechazo": 5.6
  },
  "por_circunscripcion": [
    { "circunscripcion": "SANTA_FE", "total": 89 },
    { "circunscripcion": "ROSARIO", "total": 72 },
    { "circunscripcion": "VENADO_TUERTO", "total": 38 },
    { "circunscripcion": "RAFAELA", "total": 31 },
    { "circunscripcion": "RECONQUISTA", "total": 18 }
  ],
  "tiempos_promedio": {
    "solicitud_a_revision_hs": 4.2,
    "revision_a_aprobacion_hs": 1.8,
    "aprobacion_a_pago_hs": 18.5,
    "pago_a_emision_hs": 3.1
  },
  "alertas_sla": [
    {
      "codigo": "RDAM-2025-00231",
      "nombre": "López Pérez, María",
      "circunscripcion": "ROSARIO",
      "horas_demora": 52,
      "nivel": "CRITICO"
    }
  ],
  "carga_equipo": [
    {
      "operario": { "id": "uuid", "nombre": "L. Rodríguez" },
      "asignadas": 12,
      "emitidas_mes": 8,
      "tiempo_promedio_hs": 3.2
    }
  ]
}
```

---

## USUARIOS INTERNOS (Solo SUPERVISOR)

### GET /admin/usuarios
Listar operarios.

**Response 200:**
```json
{
  "usuarios": [
    {
      "id": "uuid",
      "username": "operario.rodriguez",
      "nombre_completo": "Lucía Rodríguez",
      "rol": "OPERARIO",
      "circunscripcion": "SANTA_FE",
      "activo": true,
      "solicitudes_asignadas": 12,
      "solicitudes_emitidas_mes": 8
    }
  ]
}
```

---

### POST /admin/usuarios
Crear nuevo operario.

**Request:**
```json
{
  "username": "operario.nuevo",
  "password": "TempPass123!",
  "nombre_completo": "Nombre Apellido",
  "circunscripcion": "RAFAELA"
}
```

**Response 201:**
```json
{ "id": "uuid", "username": "operario.nuevo", "rol": "OPERARIO" }
```

---

### PATCH /admin/usuarios/:id
Actualizar operario (activar/desactivar, cambiar circunscripción).

**Request:**
```json
{ "activo": false }
```
o
```json
{ "circunscripcion": "ROSARIO" }
```

---

## CÓDIGOS DE ERROR GLOBALES

| Código HTTP | Error | Descripción |
|-------------|-------|-------------|
| 400 | `BAD_REQUEST` | Parámetros mal formados |
| 401 | `NO_AUTENTICADO` | Token ausente o inválido |
| 403 | `SIN_PERMISOS` | El rol no tiene acceso |
| 404 | `NO_ENCONTRADO` | Recurso no existe |
| 409 | `CONFLICTO` | Estado ya es el solicitado |
| 410 | `VENCIDO` | Certificado fuera de vigencia |
| 422 | `VALIDACION` | Error de validación de datos |
| 429 | `RATE_LIMIT` | Demasiadas solicitudes |
| 500 | `ERROR_INTERNO` | Error no esperado |

---

## NOTAS DE SEGURIDAD

- **Encriptación DNI/CUIL:** AES-256-GCM con IV aleatorio. La clave maestra se almacena en variable de entorno o secrets manager (AWS KMS / Vault).
- **Blind Index:** `SHA256(SALT + dni)` almacenado en `dni_hash` para habilitar búsqueda sin desencriptar.
- **Rate limiting:** 10 req/min por IP en `/solicitudes` (POST), 30 req/min en consultas.
- **Webhook:** Validar `X-Pasarela-Signature` con HMAC-SHA256 antes de procesar.
- **Upload PDF:** Validar Content-Type real (libmagic), no solo extensión. Escaneo antivirus recomendado.
