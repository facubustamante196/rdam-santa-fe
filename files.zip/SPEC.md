# ESPECIFICACIÓN FUNCIONAL: RDAM
## Poder Judicial de la Provincia de Santa Fe

**Versión:** 1.0  
**Fecha:** Enero 2025  
**Nivel:** Producción (Nivel 2)  
**Sistema:** Registro de Deudores Alimentarios Morosos — Plataforma Digital

---

## 1. Resumen Ejecutivo

El RDAM es una plataforma web que permite a ciudadanos de la Provincia de Santa Fe solicitar de forma totalmente digital su Certificado del Registro de Deudores Alimentarios Morosos. El sistema consta de dos componentes: un **Portal Ciudadano** (sin autenticación) donde el ciudadano completa su solicitud y realiza el pago, y un **Panel de Gestión Interno (Backoffice)** donde el personal del Poder Judicial revisa, aprueba y emite los certificados digitalmente.

El flujo es: Solicitud → Revisión interna → Aprobación/Rechazo → Pago → Emisión de certificado PDF. El certificado emitido tiene vigencia de 90 días desde la fecha de emisión y puede descargarse múltiples veces durante ese período.

---

## 2. Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────┐
│                    INTERNET / CIUDADANO                  │
└────────────────────────────┬────────────────────────────┘
                             │
              ┌──────────────▼──────────────┐
              │      PORTAL CIUDADANO        │
              │  (SPA sin autenticación)     │
              │  Home / Form / Pago /        │
              │  Confirmación / Historial    │
              └──────────────┬──────────────┘
                             │ REST API
┌─────────────────────────────────────────────────────────┐
│                       API BACKEND                        │
│                                                          │
│  /api/solicitudes     /api/auth     /api/usuarios        │
│  /api/pagos           /api/docs     /api/auditoria       │
└──────┬─────────────────────────────────────┬────────────┘
       │                                     │
┌──────▼──────┐  ┌──────────────┐  ┌────────▼────────┐
│  PostgreSQL  │  │  S3 / MinIO  │  │ Pasarela de Pago │
│  (datos +   │  │  (PDFs)      │  │  (externa)       │
│  auditoría) │  └──────────────┘  └─────────────────┘
└─────────────┘
       │
┌──────▼──────────────────────┐
│      BACKOFFICE INTERNO      │
│  Dashboard / Lista /         │
│  Detalle / Carga PDF /       │
│  Gestión de equipo           │
│  (JWT auth — roles)          │
└─────────────────────────────┘
```

---

## 3. Roles del Sistema

| Rol | Descripción | Capacidades |
|-----|-------------|-------------|
| **Ciudadano** | Usuario externo sin cuenta | Crear solicitud, consultar estado, pagar, descargar certificado emitido |
| **Operario/Interno** | Empleado del Poder Judicial | Login, revisar solicitudes asignadas, aprobar/rechazar, cargar PDF certificado |
| **Supervisor** | Jefe de área | Todo lo del Operario + dashboard, gestión de equipo, asignaciones, escalamiento, forzar estados |

---

## 4. Historias de Usuario

### CIUDADANO

| ID | Historia | Criterios de Aceptación |
|----|----------|------------------------|
| HU-C01 | Como ciudadano, quiero acceder al portal sin registrarme para solicitar mi certificado RDAM | • La home carga sin login • Hay CTA visible "Solicitar Certificado" • La URL es pública y accesible |
| HU-C02 | Como ciudadano, quiero completar un formulario con mis datos para iniciar la solicitud | • Campos: DNI, CUIL, Nombre completo, Fecha nacimiento, Email, Circunscripción • Validación de formato en tiempo real • DNI/CUIL encriptados antes de enviar al backend • Confirmación visual tras el envío |
| HU-C03 | Como ciudadano, quiero poder pagar mi solicitud una vez aprobada | • El ciudadano accede al pago por link/código • Se muestra monto, resumen y método de pago • Integración con pasarela externa • Pantalla de éxito con check verde y código de seguimiento |
| HU-C04 | Como ciudadano, quiero consultar el estado de mi solicitud sin tener cuenta | • Búsqueda por código de solicitud o DNI+Email • Se muestra estado actual y timeline con fechas • Los datos sensibles se muestran enmascarados |
| HU-C05 | Como ciudadano, quiero ver el historial de mis solicitudes anteriores | • Listado de solicitudes por DNI • Estado visual por solicitud • Botón de descarga habilitado solo para solicitudes emitidas y no vencidas |
| HU-C06 | Como ciudadano, quiero descargar mi certificado cuando esté emitido | • Link de descarga disponible durante 90 días desde fecha de emisión • Descargable múltiples veces • Accesible desde historial y desde email recibido |
| HU-C07 | Como ciudadano, quiero recibir un email cuando mi certificado esté listo | • Email enviado automáticamente solo al transicionar a estado "Emitida" • Email contiene: nombre, código, link de descarga, fecha de vencimiento |

### OPERARIO

| ID | Historia | Criterios de Aceptación |
|----|----------|------------------------|
| HU-O01 | Como operario, quiero iniciar sesión con usuario y contraseña | • Login con username + password • JWT con expiración de 8h + refresh 24h • Redirección según rol tras login |
| HU-O02 | Como operario, quiero ver la lista de solicitudes ordenadas por antigüedad | • Lista filtrable por estado, circunscripción, rango de fechas, DNI • Ordenamiento por defecto: más antiguas primero (ASC fecha_creacion) • Paginación de 20 registros • Solo veo solicitudes de mi circunscripción asignada |
| HU-O03 | Como operario, quiero revisar el detalle de una solicitud para aprobarla o rechazarla | • Ver todos los campos del ciudadano (DNI/CUIL enmascarados) • Panel de validación con checks automáticos simulados • Posibilidad de override manual con registro en auditoría • Botones "Aprobar" y "Rechazar" con modal de confirmación |
| HU-O04 | Como operario, quiero rechazar una solicitud con observaciones opcionales | • Modal con textarea opcional para observaciones • Al rechazar, estado pasa a "Rechazada" • El ciudadano ve las observaciones en el portal • El ciudadano debe crear una nueva solicitud (no puede editar) |
| HU-O05 | Como operario, quiero cargar el PDF de un certificado para solicitudes pagadas | • Solo solicitudes en estado "Pagada" aparecen en la cola de carga • Carga por botón clásico o drag & drop • Validación: solo PDF, máximo 5MB • Al confirmar carga: estado pasa a "Emitida" y se dispara email automático |

### SUPERVISOR

| ID | Historia | Criterios de Aceptación |
|----|----------|------------------------|
| HU-S01 | Como supervisor, quiero ver un dashboard con métricas del equipo | • KPIs: total solicitudes, pendientes, emitidas hoy, rechazadas • Gráfico de solicitudes por circunscripción • Tiempos promedio por etapa • Alertas SLA para solicitudes con >48hs sin revisión |
| HU-S02 | Como supervisor, quiero ver y filtrar todas las solicitudes del equipo | • Vista de todas las circunscripciones • Filtros adicionales por operario asignado • Visualización de SLA/demoras en la lista |
| HU-S03 | Como supervisor, quiero asignar y reasignar solicitudes entre operarios | • Asignación individual desde detalle o masiva desde lista • Selector de operario con carga de trabajo visible • Registro en auditoría al asignar/reasignar |
| HU-S04 | Como supervisor, quiero gestionar los operarios del equipo | • Crear operario: username, password temporal, circunscripción • Activar/desactivar operarios • Ver desempeño individual (asignadas, emitidas, tiempos) |
| HU-S05 | Como supervisor, quiero poder forzar cambios de estado en casos especiales | • Acción "Forzar estado" disponible solo para supervisor • Requiere justificación obligatoria • Registro en auditoría con flag "forzado_supervisor" |
| HU-S06 | Como supervisor, quiero reabrir solicitudes cerradas | • Solicitudes en estado "Rechazada" o "Emitida" pueden ser reabiertas • Solo supervisor puede realizar esta acción • Registro en auditoría |

---

## 5. Modelo de Datos

### Esquema SQL

```sql
-- USUARIOS INTERNOS
CREATE TABLE usuarios (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username      VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  nombre_completo VARCHAR(120) NOT NULL,
  rol           VARCHAR(20) NOT NULL CHECK (rol IN ('OPERARIO', 'SUPERVISOR')),
  circunscripcion VARCHAR(30) NOT NULL CHECK (circunscripcion IN ('SANTA_FE', 'ROSARIO', 'VENADO_TUERTO', 'RAFAELA', 'RECONQUISTA')),
  activo        BOOLEAN NOT NULL DEFAULT TRUE,
  fecha_creacion TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ultimo_login   TIMESTAMPTZ
);

-- SOLICITUDES
CREATE TABLE solicitudes (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo                VARCHAR(20) UNIQUE NOT NULL, -- RDAM-YYYY-NNNNN
  
  -- Datos ciudadano (encriptados)
  dni_encriptado        TEXT NOT NULL,
  cuil_encriptado       TEXT NOT NULL,
  dni_hash              VARCHAR(64) NOT NULL, -- blind index para búsqueda
  
  nombre_completo       VARCHAR(120) NOT NULL,
  fecha_nacimiento      DATE NOT NULL,
  email                 VARCHAR(120) NOT NULL,
  circunscripcion       VARCHAR(30) NOT NULL CHECK (circunscripcion IN ('SANTA_FE', 'ROSARIO', 'VENADO_TUERTO', 'RAFAELA', 'RECONQUISTA')),
  
  -- Estado y control
  estado                VARCHAR(30) NOT NULL DEFAULT 'PENDIENTE_REVISION'
                          CHECK (estado IN (
                            'PENDIENTE_REVISION',
                            'EN_REVISION',
                            'APROBADA',
                            'RECHAZADA',
                            'PENDIENTE_PAGO',
                            'PAGADA',
                            'EMITIDA'
                          )),
  operario_asignado_id  UUID REFERENCES usuarios(id),
  observaciones_rechazo TEXT,
  
  -- Certificado
  pdf_url               TEXT,
  pdf_storage_key       TEXT, -- clave en S3/MinIO
  fecha_emision         TIMESTAMPTZ,
  fecha_vencimiento     TIMESTAMPTZ, -- = fecha_emision + 90 days
  
  -- Timestamps
  fecha_creacion        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fecha_actualizacion   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX idx_solicitudes_estado ON solicitudes(estado);
CREATE INDEX idx_solicitudes_circunscripcion ON solicitudes(circunscripcion);
CREATE INDEX idx_solicitudes_fecha_creacion ON solicitudes(fecha_creacion ASC);
CREATE INDEX idx_solicitudes_dni_hash ON solicitudes(dni_hash);
CREATE INDEX idx_solicitudes_codigo ON solicitudes(codigo);

-- TRANSACCIONES DE PAGO
CREATE TABLE transacciones_pago (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  solicitud_id        UUID NOT NULL REFERENCES solicitudes(id),
  monto               DECIMAL(10,2) NOT NULL,
  estado              VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE'
                        CHECK (estado IN ('PENDIENTE', 'CONFIRMADO', 'FALLIDO', 'REEMBOLSADO')),
  referencia_pasarela VARCHAR(120),
  metodo_pago         VARCHAR(50),
  payload_pasarela    JSONB, -- respuesta completa de la pasarela
  fecha_creacion      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fecha_pago          TIMESTAMPTZ
);

-- AUDITORÍA
CREATE TABLE auditoria (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  solicitud_id    UUID REFERENCES solicitudes(id),
  usuario_id      UUID REFERENCES usuarios(id), -- NULL si es acción ciudadano/sistema
  accion          VARCHAR(80) NOT NULL,
  estado_anterior VARCHAR(30),
  estado_nuevo    VARCHAR(30),
  observaciones   TEXT,
  ip_origen       INET,
  forzado_supervisor BOOLEAN DEFAULT FALSE,
  timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_auditoria_solicitud_id ON auditoria(solicitud_id, timestamp DESC);

-- Trigger: actualizar fecha_actualizacion automáticamente
CREATE OR REPLACE FUNCTION update_fecha_actualizacion()
RETURNS TRIGGER AS $$
BEGIN
  NEW.fecha_actualizacion = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_solicitudes_updated
  BEFORE UPDATE ON solicitudes
  FOR EACH ROW EXECUTE FUNCTION update_fecha_actualizacion();

-- Trigger: calcular vencimiento al emitir
CREATE OR REPLACE FUNCTION set_fecha_vencimiento()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.estado = 'EMITIDA' AND OLD.estado != 'EMITIDA' THEN
    NEW.fecha_emision = NOW();
    NEW.fecha_vencimiento = NOW() + INTERVAL '90 days';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_set_vencimiento
  BEFORE UPDATE ON solicitudes
  FOR EACH ROW EXECUTE FUNCTION set_fecha_vencimiento();
```

### JSON Schemas

```json
// Solicitud (respuesta API)
{
  "id": "uuid",
  "codigo": "RDAM-2025-00247",
  "nombre_completo": "García Martínez, Juan Carlos",
  "email": "jgarcia@email.com",
  "fecha_nacimiento": "1985-03-15",
  "circunscripcion": "SANTA_FE",
  "estado": "EMITIDA",
  "operario_asignado": { "id": "uuid", "nombre": "L. Rodríguez" },
  "observaciones_rechazo": null,
  "pdf_url": "https://storage.rdam.gob.ar/certs/RDAM-2025-00247.pdf?token=...",
  "fecha_emision": "2025-01-15T14:30:00Z",
  "fecha_vencimiento": "2025-04-15T14:30:00Z",
  "fecha_creacion": "2025-01-14T10:32:00Z",
  "fecha_actualizacion": "2025-01-15T14:30:00Z"
}

// Creación de solicitud (request ciudadano)
{
  "dni": "30456789",           // Se encripta en el backend
  "cuil": "20304567894",       // Se encripta en el backend
  "nombre_completo": "García Martínez, Juan Carlos",
  "fecha_nacimiento": "1985-03-15",
  "email": "jgarcia@email.com",
  "circunscripcion": "SANTA_FE"
}
```

---

## 6. Flujo de Estados

```
                    ┌──────────────────┐
  [ciudadano crea]  │ PENDIENTE        │
  ────────────────► │ REVISIÓN         │
                    └────────┬─────────┘
                             │ [operario toma]
                    ┌────────▼─────────┐
                    │   EN REVISIÓN    │
                    └──┬──────────────┬┘
               [aprueba]              [rechaza]
                    │                       │
         ┌──────────▼──────┐    ┌──────────▼──────┐
         │    APROBADA      │    │    RECHAZADA     │ ◄─ fin
         └──────────┬───────┘    └─────────────────┘
     [sistema/pago] │
         ┌──────────▼──────┐
         │ PENDIENTE PAGO   │
         └──────────┬───────┘
    [webhook pago]  │
         ┌──────────▼──────┐
         │     PAGADA       │
         └──────────┬───────┘
    [operario carga]│
         ┌──────────▼──────┐
         │     EMITIDA      │ ◄─ email automático al ciudadano
         └─────────────────┘    link descarga válido 90 días
```

### Tabla de Transiciones

| Estado Origen | Estado Destino | Actor | Condiciones |
|---------------|----------------|-------|-------------|
| PENDIENTE_REVISION | EN_REVISION | Operario/Supervisor | Tomada para revisión |
| EN_REVISION | APROBADA | Operario/Supervisor | Revisión satisfactoria |
| EN_REVISION | RECHAZADA | Operario/Supervisor | No cumple requisitos |
| APROBADA | PENDIENTE_PAGO | Sistema | Automático tras aprobación |
| PENDIENTE_PAGO | PAGADA | Sistema (webhook) | Confirmación de pasarela |
| PAGADA | EMITIDA | Operario/Supervisor | Carga de PDF exitosa |
| RECHAZADA | EN_REVISION | Solo Supervisor | Reapertura de caso |
| EMITIDA | EN_REVISION | Solo Supervisor | Reapertura especial |
| Cualquiera | Cualquiera | Solo Supervisor | Forzar estado (auditado) |

---

## 7. Integraciones

### 7.1 Pasarela de Pago (Externa)

| Aspecto | Detalle |
|---------|---------|
| **Tipo** | API REST desarrollada por proveedor externo |
| **Auth** | API Key en header (a definir con proveedor) |
| **Operaciones** | Crear intención de pago, consultar estado, recibir webhook |
| **Webhook** | POST `/api/webhooks/pago` — confirma o rechaza pago |
| **Flujo** | Backend crea orden → redirige ciudadano → pasarela notifica via webhook |

```json
// Webhook entrante (pago confirmado)
{
  "evento": "PAGO_CONFIRMADO",
  "referencia_interna": "RDAM-2025-00247",
  "referencia_pasarela": "PAY-ABC-12345",
  "monto": 2750.00,
  "metodo": "TARJETA_CREDITO",
  "timestamp": "2025-01-15T09:20:00Z"
}
```

### 7.2 Servicio de Email

| Aspecto | Detalle |
|---------|---------|
| **Trigger** | Solo al transicionar a estado EMITIDA |
| **Proveedor** | SendGrid / AWS SES / Nodemailer (a definir) |
| **Template** | `rdam_certificado_emitido` |
| **Variables** | nombre_ciudadano, codigo_solicitud, link_descarga, fecha_vencimiento |
| **Link descarga** | URL presignada de S3/MinIO con expiración = fecha_vencimiento |

### 7.3 Almacenamiento de PDFs

| Aspecto | Detalle |
|---------|---------|
| **Servicio** | AWS S3 o MinIO (self-hosted) |
| **Path** | `certs/{año}/{circunscripcion}/{codigo}.pdf` |
| **Acceso** | URLs presignadas con expiración = fecha_vencimiento solicitud |
| **Límite** | 5MB por archivo |

---

## 8. Requisitos No Funcionales

### Performance
- Lista de solicitudes: respuesta < 500ms para hasta 10.000 registros
- Carga de PDF: soportar hasta 5MB, timeout de 30s
- Dashboard: caché de métricas con TTL de 5 minutos

### Seguridad
- Encriptación AES-256-GCM para campos DNI y CUIL
- Blind index (SHA-256 + salt) para búsqueda por DNI sin desencriptar
- JWT con expiración de 8h + refresh token de 24h
- Rate limiting: 10 solicitudes/minuto por IP en endpoints públicos
- Validación de tipo MIME en upload de PDF (no solo extensión)
- HTTPS obligatorio en todos los ambientes

### Disponibilidad
- SLA objetivo: 99.5% uptime
- Horario crítico: lunes a viernes 8hs–18hs

### Auditoría
- Todo cambio de estado genera registro en tabla `auditoria`
- Los registros de auditoría son inmutables (sin UPDATE/DELETE)
- Retención mínima: 5 años

### Accesibilidad
- WCAG 2.1 AA para el portal ciudadano
- Soporte para lectores de pantalla en formularios
