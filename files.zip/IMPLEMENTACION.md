# GUÍA DE IMPLEMENTACIÓN — RDAM
## Poder Judicial de Santa Fe · Nivel 2

---

## 1. Visión General

El sistema RDAM se compone de tres capas principales:
- **Frontend Portal Ciudadano** — SPA pública (Next.js o React + Vite)
- **Frontend Backoffice** — SPA con autenticación JWT (React + React Router)
- **Backend API** — REST API (Node.js/Express o NestJS) + PostgreSQL + S3

Ambos frontends consumen la misma API backend. El portal ciudadano no requiere autenticación pero sí rate limiting. El backoffice requiere JWT con roles.

---

## 2. Stack Tecnológico Recomendado

### Backend
- **Runtime:** Node.js 20+ con TypeScript
- **Framework:** NestJS (recomendado por estructura modular) o Express
- **ORM:** Prisma o TypeORM
- **Base de datos:** PostgreSQL 15+
- **Almacenamiento PDF:** AWS S3 o MinIO (self-hosted)
- **Email:** Nodemailer + SendGrid o AWS SES
- **Auth:** JWT (jsonwebtoken) + bcrypt para passwords
- **Validación:** class-validator / zod
- **Testing:** Jest + Supertest

### Frontend
- **Framework:** Next.js 14+ (App Router) o React + Vite
- **Estilos:** Tailwind CSS
- **Estado:** React Query (TanStack) para datos server-side
- **Formularios:** React Hook Form + zod
- **HTTP:** Axios o fetch nativo

### Infraestructura
- **Contenedores:** Docker + Docker Compose (dev), Kubernetes u ECS (prod)
- **CI/CD:** GitHub Actions o GitLab CI
- **Ambientes:** develop, staging, production

---

## 3. Plan de Sprints

### Sprint 0 — Setup (1 semana)
**Objetivo:** Infraestructura base lista y equipos alineados.

- [ ] Crear repositorios (monorepo o repos separados)
- [ ] Configurar Docker Compose local (API + Postgres + MinIO)
- [ ] Definir estructura de carpetas del proyecto
- [ ] Configurar ESLint, Prettier, Husky
- [ ] Crear ambientes develop y staging
- [ ] Definir variables de entorno y secrets (ver sección 5)
- [ ] Integrar pipeline CI básico (build + lint)
- [ ] Reunión de definición de monto del certificado (pendiente)
- [ ] Reunión de integración con proveedor de pasarela de pago

---

### Sprint 1 — Fundaciones (2 semanas)
**HUs:** HU-C01, HU-C02, HU-O01  
**Objetivo:** Solicitud básica y autenticación funcionando.

**Backend:**
- [ ] Migraciones de base de datos (tablas solicitudes, usuarios, auditoria, transacciones_pago)
- [ ] Módulo de autenticación (login, JWT, refresh token)
- [ ] Endpoint POST /solicitudes con encriptación DNI/CUIL
- [ ] Endpoint GET /admin/solicitudes (lista básica sin filtros avanzados)
- [ ] Endpoint GET /admin/solicitudes/:id
- [ ] Trigger de auditoría automática en cambios de estado
- [ ] Generador de código RDAM-YYYY-NNNNN (secuencia con año)
- [ ] Seed de datos: usuarios internos de prueba

**Frontend Portal:**
- [ ] Home con CTA
- [ ] Formulario de solicitud con validaciones
- [ ] Pantalla de "Solicitud enviada" con código

**Frontend Backoffice:**
- [ ] Pantalla de login
- [ ] Lista de solicitudes básica (sin filtros avanzados)
- [ ] Vista de detalle básica

---

### Sprint 2 — Flujo de Revisión (2 semanas)
**HUs:** HU-O02, HU-O03, HU-O04, HU-S03  
**Objetivo:** Operario puede revisar, aprobar y rechazar.

**Backend:**
- [ ] PATCH /admin/solicitudes/:id/estado con validación de transiciones
- [ ] Middleware de validación de roles por endpoint
- [ ] Endpoint PATCH /admin/solicitudes/:id/asignar
- [ ] Filtros avanzados en GET /admin/solicitudes (estado, circunscripción, fecha, DNI)
- [ ] Override manual con registro de auditoría
- [ ] Validaciones automáticas simuladas al abrir detalle

**Frontend Portal:**
- [ ] Pantalla de Consulta de Estado con timeline
- [ ] Pantalla de Historial de solicitudes

**Frontend Backoffice:**
- [ ] Toolbar de filtros avanzados en lista
- [ ] Panel de validación en detalle con checks y override
- [ ] Modales de Aprobar y Rechazar
- [ ] Modal de Reasignar (visible solo para Supervisor)
- [ ] Historial de auditoría en detalle
- [ ] Diferenciación visual de roles (sidebar según rol)

---

### Sprint 3 — Pago y Emisión (2 semanas)
**HUs:** HU-C03, HU-C06, HU-C07, HU-O05  
**Objetivo:** Flujo de pago y carga de certificado completo.

**Backend:**
- [ ] POST /pagos/iniciar — integración con pasarela externa
- [ ] POST /webhooks/pago — recepción y validación de webhook
- [ ] POST /admin/solicitudes/:id/pdf — upload a S3/MinIO
- [ ] Generación de URL presignada con expiración = fecha_vencimiento
- [ ] Cálculo automático de fecha_vencimiento = fecha_emision + 90 días (trigger DB)
- [ ] Servicio de email (template rdam_certificado_emitido)
- [ ] GET /solicitudes/:codigo/download — redirect a URL presignada

**Frontend Portal:**
- [ ] Pantalla de Pago con integración a pasarela (redirect o iframe)
- [ ] Pantalla de Confirmación con check verde
- [ ] Botón de descarga en historial (habilitado si emitida y vigente)

**Frontend Backoffice:**
- [ ] Vista Cargar PDF con drag & drop y botón clásico
- [ ] Cola de espera de solicitudes PAGADAS
- [ ] Confirmación de emisión con toast de éxito

---

### Sprint 4 — Dashboard y Supervisor (2 semanas)
**HUs:** HU-S01, HU-S02, HU-S04, HU-S05, HU-S06  
**Objetivo:** Funcionalidades completas del Supervisor.

**Backend:**
- [ ] GET /admin/dashboard con todas las métricas
- [ ] Cron job de SLA — detectar solicitudes con demora > 30hs (warning) y > 48hs (crítico)
- [ ] POST /admin/usuarios — crear operario
- [ ] PATCH /admin/usuarios/:id — activar/desactivar, cambiar circunscripción
- [ ] Lógica de "Forzar estado" con flag en auditoría
- [ ] Lógica de "Reabrir caso" (transición especial)

**Frontend Backoffice:**
- [ ] Dashboard con KPIs, gráfico de barras, alertas SLA
- [ ] Tabla de carga de trabajo del equipo
- [ ] Vista de Gestión de Equipo con tabs (Operarios / Asignaciones)
- [ ] Panel de acciones Supervisor en vista de Detalle
- [ ] Modal de Nuevo Operario
- [ ] Filtro por operario en lista (solo Supervisor)

---

### Sprint 5 — Hardening y Calidad (1 semana)
**Objetivo:** Seguridad, performance y testing antes de QA.

- [ ] Rate limiting en endpoints públicos
- [ ] Validación real de MIME type en upload PDF
- [ ] Tests unitarios de lógica de negocio (transiciones de estado, encriptación)
- [ ] Tests de integración de endpoints críticos (crear solicitud, webhook pago, cargar PDF)
- [ ] Tests E2E del happy path completo (Cypress o Playwright)
- [ ] Auditoría de seguridad básica (OWASP Top 10)
- [ ] Optimización de queries con índices
- [ ] Configurar logs estructurados (Winston/Pino)
- [ ] Documentación de API (Swagger/OpenAPI)

---

## 4. Decisiones Técnicas a Resolver Antes de Empezar

| Decisión | Opciones | Recomendación |
|----------|----------|---------------|
| Monto del certificado | Fijo hardcodeado vs configurable en DB | Variable en config/env para poder cambiar sin deploy |
| Pasarela de pago | MercadoPago, PayU, Getnet, custom | Confirmar con equipo — afecta Sprint 3 |
| Hosting | On-premise, AWS, Azure | Definir antes del Sprint 0 |
| Storage PDFs | AWS S3, MinIO self-hosted | MinIO si se requiere on-premise |
| Proveedor email | SendGrid, AWS SES, Nodemailer SMTP | SendGrid recomendado por templates |
| Monorepo vs repos separados | Turborepo, Nx, repos separados | Turborepo si mismo equipo maneja todo |
| Encriptación DNI/CUIL | AES-256-GCM, KMS | AES-256-GCM + clave en env/Vault |

---

## 5. Variables de Entorno

### Backend (.env)
```env
# Base de datos
DATABASE_URL=postgresql://user:pass@localhost:5432/rdam

# JWT
JWT_SECRET=super-secret-key-256bits
JWT_EXPIRES_IN=8h
JWT_REFRESH_EXPIRES_IN=24h

# Encriptación
ENCRYPTION_KEY=32-bytes-hex-key

# Blind index salt
DNI_HASH_SALT=random-salt-value

# S3 / MinIO
S3_ENDPOINT=https://s3.amazonaws.com
S3_BUCKET=rdam-certificados
S3_ACCESS_KEY=AKIAIOSFODNN7EXAMPLE
S3_SECRET_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
S3_REGION=us-east-1

# Email
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=SG.xxx
EMAIL_FROM=noreply@rdam.justiciasantafe.gov.ar
EMAIL_TEMPLATE_EMISION=d-xxxxxxxxx

# Pasarela de pago
PASARELA_API_URL=https://pasarela.proveedor.com
PASARELA_API_KEY=key-aqui
PASARELA_WEBHOOK_SECRET=secret-webhook

# App
FRONTEND_URL=https://rdam.justiciasantafe.gov.ar
BACKEND_URL=https://api.rdam.justiciasantafe.gov.ar
PORT=3000
NODE_ENV=production

# SLA
SLA_WARNING_HOURS=30
SLA_CRITICAL_HOURS=48
```

---

## 6. Testing

### Cobertura mínima esperada
- Lógica de negocio (transiciones de estado, encriptación): **90%**
- Endpoints API (integración): **80%**
- Componentes UI críticos: **70%**

### Tests críticos a implementar

**Backend — Unit:**
```
□ StateTransitionService: validar todas las transiciones permitidas y denegadas
□ EncryptionService: cifrar/descifrar DNI y CUIL
□ BlindIndexService: consistencia de hash para búsqueda
□ CertificadoService: cálculo de fecha_vencimiento
□ WebhookValidator: validar firma HMAC de pasarela
```

**Backend — Integration:**
```
□ POST /solicitudes → crea solicitud con DNI encriptado
□ POST /auth/login → retorna JWT válido
□ PATCH /admin/solicitudes/:id/estado (APROBADA) → transición y auditoría
□ PATCH /admin/solicitudes/:id/estado (transición inválida) → error 422
□ POST /webhooks/pago → cambia estado a PAGADA
□ POST /admin/solicitudes/:id/pdf → sube PDF, estado EMITIDA, email enviado
□ GET /solicitudes/:codigo/download → redirect a URL presignada
□ GET /solicitudes/:codigo/download (vencido) → error 410
```

**E2E — Playwright/Cypress:**
```
□ Happy path completo: Solicitud → Aprobación → Pago → Emisión → Descarga
□ Rechazo: Solicitud → Rechazo con observaciones → visible en portal
□ Supervisor: Login → Dashboard → Asignar solicitud → Forzar estado
□ Descarga vencida: PDF no disponible tras 90 días
```

---

## 7. Deployment

### Docker Compose (Desarrollo local)
```yaml
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: rdam
      POSTGRES_USER: rdam_user
      POSTGRES_PASSWORD: local_pass
    ports: ['5432:5432']
    volumes: ['pgdata:/var/lib/postgresql/data']

  minio:
    image: minio/minio
    ports: ['9000:9000', '9001:9001']
    command: server /data --console-address ":9001"
    volumes: ['miniodata:/data']

  api:
    build: ./apps/api
    ports: ['3001:3000']
    depends_on: [db, minio]
    env_file: .env

  portal:
    build: ./apps/portal
    ports: ['3002:3000']

  backoffice:
    build: ./apps/backoffice
    ports: ['3003:3000']

volumes:
  pgdata:
  miniodata:
```

### Ambientes

| Ambiente | URL | Deploy trigger |
|----------|-----|----------------|
| **Develop** | dev.rdam.internal | Push a rama `develop` |
| **Staging** | staging.rdam.internal | PR a `main` |
| **Production** | rdam.justiciasantafe.gov.ar | Tag de release |

---

## 8. Checklist de Entrega

### Pre-QA
- [ ] Todos los endpoints documentados en Swagger
- [ ] Tests unitarios e integración al verde
- [ ] Variables de entorno documentadas
- [ ] Migraciones de base de datos probadas en ambiente limpio
- [ ] Logs estructurados funcionando
- [ ] Rate limiting activo en endpoints públicos
- [ ] Validación de MIME type en upload PDF
- [ ] Firma de webhook validada

### Pre-PROD
- [ ] Auditoría de seguridad realizada
- [ ] Certificado SSL instalado
- [ ] Backup automatizado de base de datos
- [ ] Monitoreo configurado (uptime + errores)
- [ ] Runbook de operación documentado
- [ ] Capacitación al personal interno completada
- [ ] Datos de prueba eliminados de la base
- [ ] Credenciales de producción rotadas
- [ ] Cron de SLA verificado en ejecución
- [ ] Template de email probado con cuenta real
- [ ] Test E2E en staging con pasarela en modo sandbox
- [ ] Definición del monto final del certificado ingresado en config

---

## 9. Prompts para Generar Código con IA

### Backend — Módulo de Solicitudes
```
Sos un desarrollador backend experto en NestJS y TypeScript.
Creá el módulo de solicitudes para el sistema RDAM con:
- Entity: Solicitud con campos (ver SPEC.md sección 5)
- DTO de creación: validar DNI, CUIL, nombre, fecha_nacimiento, email, circunscripcion
- Servicio con método crear() que:
  1. Encripta DNI y CUIL con AES-256-GCM
  2. Genera blind index hash(SALT + dni)
  3. Genera código RDAM-YYYY-NNNNN secuencial
  4. Guarda en DB con estado PENDIENTE_REVISION
  5. Registra en tabla auditoria
- Controller con endpoint POST /solicitudes (público, sin auth)
- Rate limiting: 10/min por IP
Usá Prisma como ORM. PostgreSQL. No incluyas lógica de pago.
```

### Backend — Servicio de Transiciones de Estado
```
Sos un desarrollador backend experto en NestJS.
Implementá StateTransitionService para el sistema RDAM.
Las transiciones válidas son (ver SPEC.md sección 6).
El servicio debe:
1. Validar si la transición es permitida según el rol del usuario (OPERARIO, SUPERVISOR)
2. Si no es válida, lanzar UnprocessableEntityException con mensaje claro
3. Supervisores pueden forzar cualquier transición con flag forzado=true
4. Al cambiar estado: actualizar solicitud + registrar en tabla auditoria
5. Si nuevo estado = EMITIDA: disparar evento que trigger el envío de email
Implementá con patrón máquina de estados. Incluí tests unitarios con Jest.
```

### Frontend — Componente Formulario Ciudadano
```
Sos un desarrollador frontend experto en React, TypeScript y Tailwind CSS.
Creá el componente FormularioCiudadano para el portal RDAM.
Campos: DNI, CUIL, nombre_completo, fecha_nacimiento, email, circunscripcion (5 opciones).
Requisitos:
- React Hook Form + zod para validación
- Validación en tiempo real con feedback visual
- Selector visual de circunscripción (cards clickeables, no select nativo)
- Mensaje de encriptación junto a DNI y CUIL
- Al enviar: POST /api/solicitudes, mostrar código de seguimiento generado
- Manejo de errores de red con mensaje amigable
- No usar librerías de UI (solo Tailwind)
```
